Rebuild with NDK r28c and Python 3.11+:
python tool/build_android_media.py --ndk <NDK> --work-dir <new-ASCII-directory> --output third_party/cmp_android_media/vendor --source-cache .
Windows: provide --make <GNU-Make> and --bash <Git-Bash>; a full MSVC SDK is needed.
Build tool changes are generated configuration only; upstream FFmpeg source is unchanged.
Replace the APK lib/arm64-v8a/libav*.so and libswresample.so with rebuilt libraries,
zipalign -P 16, then apksigner sign with your own key.
To rebuild the JNI wrapper, use the included CMake project with Android NDK.
