Rebuild with NDK r28c and Python 3.11+:
python tool/build_android_media.py --ndk <NDK> --work-dir <new-ASCII-directory> --output third_party/cmp_android_media/vendor --source-cache .
Windows: provide --make <GNU-Make> and --bash <Git-Bash>; a full MSVC SDK is needed.
Build tool changes are generated configuration only; upstream FFmpeg source is unchanged.
Use CMake 3.22+ with the Android NDK toolchain, ANDROID_ABI=arm64-v8a,
ANDROID_PLATFORM=android-24 and ANDROID_STL=c++_static on third_party/cmp_android_media.
Its CMake project builds the JNI wrapper and the separate Chromaprint library.
Replace the corresponding APK libraries in lib/arm64-v8a, run zipalign -P 16,
then sign the APK with apksigner and your own key.
